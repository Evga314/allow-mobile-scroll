package com.mojang.renderpearl.backend.common;

import com.mojang.renderpearl.api.buffers.GpuBuffer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public abstract class BaseGpuBuffer implements GpuBuffer {
	private final @GpuBuffer.Usage int usage;
	private final long size;

	public BaseGpuBuffer(final @GpuBuffer.Usage int usage, final long size) {
		this.size = size;
		this.usage = usage;
	}

	@Override
	public long size() {
		return this.size;
	}

	@Override
	public @GpuBuffer.Usage int usage() {
		return this.usage;
	}

	public void checkCanBeUsed() {
	}
}
