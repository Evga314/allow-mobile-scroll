@NullMarked
@Environment(EnvType.CLIENT)
package com.mojang.renderpearl.backend.common;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.NullMarked;
