package com.mojang.renderpearl.backend.opengl;

import com.mojang.renderpearl.api.buffers.GpuBuffer;
import java.nio.ByteBuffer;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.lwjgl.opengl.GLCapabilities;

@Environment(EnvType.CLIENT)
public abstract class BufferStorage {
	public static BufferStorage create(final GLCapabilities capabilities, final Set<String> enabledExtensions, final boolean forceMutable) {
		if (!forceMutable && capabilities.GL_ARB_buffer_storage && GlDevice.USE_GL_ARB_buffer_storage) {
			enabledExtensions.add("GL_ARB_buffer_storage");
			return new BufferStorage.Immutable();
		} else {
			return new BufferStorage.Mutable();
		}
	}

	public abstract GlBuffer createBuffer(GlHeuristics heuristics, DirectStateAccess dsa, @GpuBuffer.Usage int usage, long size);

	public abstract GlBuffer createBuffer(GlHeuristics heuristics, DirectStateAccess dsa, @GpuBuffer.Usage int usage, ByteBuffer data);

	@Environment(EnvType.CLIENT)
	private static class Immutable extends BufferStorage {
		@Override
		public GlBuffer createBuffer(final GlHeuristics heuristics, final DirectStateAccess dsa, final @GpuBuffer.Usage int usage, final long size) {
			int buffer = dsa.createBuffer();
			dsa.bufferStorage(buffer, size, usage);
			return new GlBuffer.Direct(heuristics, dsa, usage, size, buffer, true);
		}

		@Override
		public GlBuffer createBuffer(final GlHeuristics heuristics, final DirectStateAccess dsa, final @GpuBuffer.Usage int usage, final ByteBuffer data) {
			int buffer = dsa.createBuffer();
			int size = data.remaining();
			dsa.bufferStorage(buffer, data, usage);
			return new GlBuffer.Direct(heuristics, dsa, usage, size, buffer, true);
		}
	}

	@Environment(EnvType.CLIENT)
	private static class Mutable extends BufferStorage {
		@Override
		public GlBuffer createBuffer(final GlHeuristics heuristics, final DirectStateAccess dsa, final @GpuBuffer.Usage int usage, final long size) {
			int buffer = dsa.createBuffer();
			dsa.bufferData(buffer, size, usage);
			return new GlBuffer.Direct(heuristics, dsa, usage, size, buffer, false);
		}

		@Override
		public GlBuffer createBuffer(final GlHeuristics heuristics, final DirectStateAccess dsa, final @GpuBuffer.Usage int usage, final ByteBuffer data) {
			int buffer = dsa.createBuffer();
			int size = data.remaining();
			dsa.bufferData(buffer, data, usage);
			return new GlBuffer.Direct(heuristics, dsa, usage, size, buffer, false);
		}
	}
}
