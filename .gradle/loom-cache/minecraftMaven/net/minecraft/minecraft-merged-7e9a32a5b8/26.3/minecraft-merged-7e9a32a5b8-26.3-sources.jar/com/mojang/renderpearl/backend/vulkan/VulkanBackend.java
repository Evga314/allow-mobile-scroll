package com.mojang.renderpearl.backend.vulkan;

import com.mojang.blaze3d.platform.NativeLibrariesBootstrap;
import com.mojang.logging.LogUtils;
import com.mojang.renderpearl.api.device.BackendCreationException;
import com.mojang.renderpearl.api.device.GpuBackend;
import com.mojang.renderpearl.api.device.GpuDebugOptions;
import com.mojang.renderpearl.api.device.GpuDevice;
import com.mojang.renderpearl.backend.vulkan.checkpoints.AmdCheckpointExtension;
import com.mojang.renderpearl.backend.vulkan.checkpoints.CheckpointExtension;
import com.mojang.renderpearl.backend.vulkan.checkpoints.NoopCheckpointExtension;
import com.mojang.renderpearl.backend.vulkan.checkpoints.NvidiaCheckpointExtension;
import com.mojang.renderpearl.backend.vulkan.init.FeatureSet;
import com.mojang.renderpearl.backend.vulkan.init.VulkanFeature;
import com.mojang.renderpearl.frontend.FrontendGpuDevice;
import it.unimi.dsi.fastutil.ints.Int2IntMap;
import it.unimi.dsi.fastutil.ints.Int2IntMap.Entry;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import it.unimi.dsi.fastutil.objects.ReferenceArrayList;
import java.nio.IntBuffer;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.Nullable;
import org.lwjgl.PointerBuffer;
import org.lwjgl.sdl.SDLError;
import org.lwjgl.sdl.SDLVideo;
import org.lwjgl.sdl.SDLVulkan;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.SharedLibrary;
import org.lwjgl.util.vma.Vma;
import org.lwjgl.util.vma.VmaAllocatorCreateInfo;
import org.lwjgl.util.vma.VmaVulkanFunctions;
import org.lwjgl.vulkan.VK;
import org.lwjgl.vulkan.VK12;
import org.lwjgl.vulkan.VkDevice;
import org.lwjgl.vulkan.VkDeviceCreateInfo;
import org.lwjgl.vulkan.VkDeviceQueueCreateInfo;
import org.lwjgl.vulkan.VkPhysicalDevice;
import org.lwjgl.vulkan.VkPhysicalDeviceFeatures2;
import org.lwjgl.vulkan.VkPhysicalDeviceProperties;
import org.lwjgl.vulkan.VkPhysicalDeviceProperties2;
import org.lwjgl.vulkan.VkDeviceQueueCreateInfo.Buffer;
import org.slf4j.Logger;

@Environment(EnvType.CLIENT)
public class VulkanBackend implements GpuBackend {
	private static final Logger LOGGER = LogUtils.getLogger();
	private boolean libraryLoaded;
	private @Nullable BackendCreationException libraryLoadFailure;

	@Override
	public String getName() {
		return "Vulkan";
	}

	@Override
	public void loadLibrary() throws BackendCreationException {
		if (!this.libraryLoaded) {
			if (this.libraryLoadFailure != null) {
				throw this.libraryLoadFailure;
			}

			if (!NativeLibrariesBootstrap.isVulkanLoaderAvailable()) {
				this.libraryLoadFailure = new BackendCreationException("Vulkan loader library is missing", BackendCreationException.Reason.VULKAN_LOADER_MISSING);
				throw this.libraryLoadFailure;
			}

			if (!SDLVulkan.SDL_Vulkan_LoadLibrary(((SharedLibrary)VK.getFunctionProvider()).getPath())) {
				this.libraryLoadFailure = new BackendCreationException(
					"Vulkan is not supported: " + Objects.requireNonNullElse(SDLError.SDL_GetError(), "<no error>"), BackendCreationException.Reason.PLATFORM_ERROR
				);
				throw this.libraryLoadFailure;
			}

			if (VK.getFunctionProvider().getFunctionAddress("vkGetInstanceProcAddr") != SDLVulkan.SDL_Vulkan_GetVkGetInstanceProcAddr()) {
				this.libraryLoadFailure = new BackendCreationException("vkGetInstanceProcAddr mismatch", BackendCreationException.Reason.PLATFORM_ERROR);
				SDLVulkan.SDL_Vulkan_UnloadLibrary();
				throw this.libraryLoadFailure;
			}

			this.libraryLoaded = true;
		}
	}

	@Override
	public void unloadLibrary() {
		if (this.libraryLoaded) {
			SDLVulkan.SDL_Vulkan_UnloadLibrary();
			this.libraryLoaded = false;
		}
	}

	public static @Nullable BackendCreationException checkBackendAvailable() {
		VulkanBackend probe = new VulkanBackend();

		try {
			probe.loadLibrary();
		} catch (BackendCreationException e) {
			return e;
		}

		try {
			return probe.checkBackendAvailableWithLoadedLibrary();
		} finally {
			probe.unloadLibrary();
		}
	}

	private @Nullable BackendCreationException checkBackendAvailableWithLoadedLibrary() {
		Set<FeatureSet> requiredFeatureSets = VulkanFeatureSets.requiredFeatureSets();
		Set<FeatureSet> requiredIfExtensionsAvailableFeatureSets = VulkanFeatureSets.requiredIfExtensionsAvailableFeatureSets();

		try (
			VulkanInstance instance = new VulkanInstance(0, false, false);
			VulkanPhysicalDevice physicalDevice = findPhysicalDevice(instance, requiredFeatureSets, requiredIfExtensionsAvailableFeatureSets);
		) {
			return null;
		} catch (BackendCreationException e) {
			return e;
		}
	}

	@Override
	public long createWindow(final @Nullable String title, final int width, final int height, final long flags) {
		return SDLVideo.SDL_CreateWindow(title, width, height, 268435456L | flags);
	}

	@Override
	public GpuDevice createDevice(final GpuDebugOptions debugOptions) throws BackendCreationException {
		if (!NativeLibrariesBootstrap.isVulkanLoaderAvailable()) {
			throw new BackendCreationException("Vulkan loader library is missing", BackendCreationException.Reason.VULKAN_LOADER_MISSING);
		}

		Set<FeatureSet> requiredFeatureSets = VulkanFeatureSets.requiredFeatureSets();
		Set<FeatureSet> requiredIfExtensionsAvailableFeatureSets = VulkanFeatureSets.requiredIfExtensionsAvailableFeatureSets();
		Set<FeatureSet> optionalFeatureSets = VulkanFeatureSets.optionalFeatureSets();
		VulkanInstance instance = null;
		VulkanPhysicalDevice physicalDevice = null;
		VkDevice device = null;
		long vma = 0L;
		CheckpointExtension checkpointExtension = NoopCheckpointExtension.INSTANCE;

		FeatureSet enabledFeatures;
		try {
			boolean renderdocAttached = "1".equals(System.getenv("ENABLE_VULKAN_RENDERDOC_CAPTURE"));
			instance = new VulkanInstance(debugOptions.logLevel(), debugOptions.useLabels() || renderdocAttached, debugOptions.useValidationLayers());
			physicalDevice = findPhysicalDevice(instance, requiredFeatureSets, requiredIfExtensionsAvailableFeatureSets);
			Set<String> deviceExtensions = VulkanUtils.enumerateExtensions(physicalDevice.vkPhysicalDevice());
			Set<FeatureSet> enabledFeatureSets = new ObjectOpenHashSet<>(requiredFeatureSets);

			for (FeatureSet featureSet : requiredIfExtensionsAvailableFeatureSets) {
				if (featureSet.isSupported(physicalDevice.vkPhysicalDevice(), deviceExtensions)) {
					enabledFeatureSets.add(featureSet);
					LOGGER.info("Enabling required for device FeatureSet [{}]", featureSet.name());
				}
			}

			for (FeatureSet featureSet : optionalFeatureSets) {
				if (featureSet.isSupported(physicalDevice.vkPhysicalDevice(), deviceExtensions)) {
					if (featureSet.checkCondition(physicalDevice.vkPhysicalDevice())) {
						enabledFeatureSets.add(featureSet);
						LOGGER.info("Enabling optional FeatureSet [{}]", featureSet.name());
					} else {
						LOGGER.info("Optional FeatureSet [{}] supported but device condition failed and will not be enabled", featureSet.name());
					}
				} else {
					LOGGER.info("Optional FeatureSet [{}] not supported", featureSet.name());
				}
			}

			if (enabledFeatureSets.contains(VulkanFeatureSets.AMD_BUFFER_MARKER_FEATURESET)) {
				checkpointExtension = new AmdCheckpointExtension();
			} else if (enabledFeatureSets.contains(VulkanFeatureSets.NV_DIAGNOSTIC_CHECKPOINT_FEATURESET)) {
				checkpointExtension = new NvidiaCheckpointExtension();
			}

			enabledFeatures = new FeatureSet("Enabled", enabledFeatureSets);
			device = createDevice(enabledFeatures, physicalDevice);
			vma = createVma(device);
		} catch (BackendCreationException e) {
			if (vma != 0L) {
				Vma.vmaDestroyAllocator(vma);
			}

			if (device != null) {
				VK12.vkDestroyDevice(device, null);
			}

			if (physicalDevice != null) {
				physicalDevice.close();
			}

			if (instance != null) {
				instance.close();
			}

			throw e;
		}

		return new FrontendGpuDevice(new VulkanDevice(instance, physicalDevice, enabledFeatures, device, vma, checkpointExtension));
	}

	private static long createVma(final VkDevice vkDevice) throws BackendCreationException {
		try (MemoryStack stack = MemoryStack.stackPush()) {
			VmaVulkanFunctions vmaVulkanFunctions = VmaVulkanFunctions.calloc(stack).set(vkDevice.getPhysicalDevice().getInstance(), vkDevice);
			VmaAllocatorCreateInfo createInfo = VmaAllocatorCreateInfo.calloc(stack)
				.instance(vkDevice.getPhysicalDevice().getInstance())
				.vulkanApiVersion(VK12.VK_API_VERSION_1_2)
				.device(vkDevice)
				.physicalDevice(vkDevice.getPhysicalDevice())
				.pVulkanFunctions(vmaVulkanFunctions);
			PointerBuffer pointer = stack.callocPointer(1);
			VulkanUtils.throwIfFailure(Vma.vmaCreateAllocator(createInfo, pointer), "Failed to create VMA allocator", BackendCreationException.Reason.OTHER);
			return pointer.get(0);
		}
	}

	private static VulkanPhysicalDevice findPhysicalDevice(
		final VulkanInstance instance, final Set<FeatureSet> requiredFeatureSets, final Set<FeatureSet> requiredIfExtensionsAvailable
	) throws BackendCreationException {
		BackendCreationException deviceFailureReason = null;
		VkPhysicalDevice selectedDevice = null;

		try (MemoryStack stack = MemoryStack.stackPush()) {
			IntBuffer intBuffer = stack.callocInt(1);
			VulkanUtils.throwIfFailure(
				VK12.vkEnumeratePhysicalDevices(instance.vkInstance(), intBuffer, null),
				"Failed to get number of physical devices",
				BackendCreationException.Reason.VULKAN_NO_DEVICE
			);
			if (intBuffer.get(0) == 0) {
				throw new BackendCreationException("No Vulkan capable devices", BackendCreationException.Reason.VULKAN_NO_DEVICE);
			}

			PointerBuffer pPhysicalDevices = stack.callocPointer(intBuffer.get(0));
			VulkanUtils.throwIfFailure(
				VK12.vkEnumeratePhysicalDevices(instance.vkInstance(), intBuffer, pPhysicalDevices),
				"Failed to get physical devices",
				BackendCreationException.Reason.VULKAN_NO_DEVICE
			);
			int numDevices = intBuffer.get(0);
			if (numDevices == 0) {
				throw new BackendCreationException("No Vulkan capable devices", BackendCreationException.Reason.VULKAN_NO_DEVICE);
			}

			for (int i = 0; i < numDevices; i++) {
				if (pPhysicalDevices.get(i) != 0L) {
					VkPhysicalDevice currentDevice = new VkPhysicalDevice(pPhysicalDevices.get(i), instance.vkInstance());
					BackendCreationException failureReason = checkDeviceSuitability(currentDevice, requiredFeatureSets, requiredIfExtensionsAvailable);
					if (failureReason != null) {
						if (deviceFailureReason == null) {
							deviceFailureReason = failureReason;
						}
					} else if (selectedDevice == null) {
						selectedDevice = currentDevice;
					} else if (isDeviceDiscrete(currentDevice) && !isDeviceDiscrete(selectedDevice)) {
						LOGGER.info("Preferring discrete GPU: {}", getDeviceName(currentDevice));
						selectedDevice = currentDevice;
						break;
					}
				}
			}
		}

		if (selectedDevice == null) {
			if (deviceFailureReason == null) {
				throw new BackendCreationException("No Vulkan capable devices", BackendCreationException.Reason.VULKAN_NO_DEVICE);
			} else {
				throw deviceFailureReason;
			}
		} else {
			return new VulkanPhysicalDevice(selectedDevice);
		}
	}

	private static boolean deviceMeetsFeatureQueryRequirements(final VkPhysicalDevice vkPhysicalDevice) {
		try (MemoryStack stack = MemoryStack.stackPush()) {
			VkPhysicalDeviceProperties properties = VkPhysicalDeviceProperties.calloc(stack);
			VK12.vkGetPhysicalDeviceProperties(vkPhysicalDevice, properties);
			return properties.apiVersion() >= VK12.VK_API_VERSION_1_1;
		}
	}

	private static boolean isDeviceDiscrete(final VkPhysicalDevice vkPhysicalDevice) {
		try (MemoryStack stack = MemoryStack.stackPush()) {
			VkPhysicalDeviceProperties2 deviceProperties = VkPhysicalDeviceProperties2.calloc(stack).sType$Default();
			VK12.vkGetPhysicalDeviceProperties2(vkPhysicalDevice, deviceProperties);
			return deviceProperties.properties().deviceType() == 2;
		}
	}

	private static String getDeviceName(final VkPhysicalDevice vkPhysicalDevice) {
		try (MemoryStack stack = MemoryStack.stackPush()) {
			VkPhysicalDeviceProperties2 deviceProperties = VkPhysicalDeviceProperties2.calloc(stack).sType$Default();
			VK12.vkGetPhysicalDeviceProperties2(vkPhysicalDevice, deviceProperties);
			return deviceProperties.properties().deviceNameString();
		}
	}

	private static BackendCreationException checkDeviceSuitability(
		final VkPhysicalDevice vkPhysicalDevice, final Set<FeatureSet> requiredFeatureSets, final Set<FeatureSet> requiredIfExtensionsAvailable
	) throws BackendCreationException {
		try (VulkanPhysicalDevice physicalDevice = new VulkanPhysicalDevice(vkPhysicalDevice)) {
			String deviceName = physicalDevice.deviceName();
			if (!deviceMeetsFeatureQueryRequirements(vkPhysicalDevice)) {
				LOGGER.warn("Device [{}] does not support Vulkan 1.1, skipping further capability checks", deviceName);
				return new BackendCreationException(
					"Device missing capabilities", BackendCreationException.Reason.VULKAN_DEVICE_VERSION_TOO_LOW, List.of("VULKAN_CORE_1_1")
				);
			}

			VulkanUtils.DeviceUUID deviceUUID = new VulkanUtils.DeviceUUID(
				physicalDevice.vkPhysicalDeviceDriverProperties().driverID(),
				physicalDevice.vkPhysicalDeviceProperties().vendorID(),
				physicalDevice.vkPhysicalDeviceProperties().deviceID()
			);
			if (VulkanUtils.KNOWN_PROBLEMATIC_DEVICES.contains(deviceUUID)) {
				LOGGER.warn("Device [{}] is known to be problematic, skipping", deviceName);
				return new BackendCreationException("Device known problematic", BackendCreationException.Reason.VULKAN_KNOWN_PROBLEMATIC, List.of());
			}

			Set<FeatureSet> deviceRequiredFeatureSets = new ObjectOpenHashSet<>(requiredFeatureSets);
			Set<String> deviceExtensions = VulkanUtils.enumerateExtensions(vkPhysicalDevice);

			for (FeatureSet featureSet : requiredIfExtensionsAvailable) {
				if (deviceExtensions.containsAll(featureSet.extensions())) {
					LOGGER.warn("Device [{}] supports all extensions from FeatureSet [{}], making required", deviceName, featureSet.name());
					deviceRequiredFeatureSets.add(featureSet);
				}
			}

			List<String> missingCapabilities = new ReferenceArrayList<>();
			BackendCreationException.Reason mostProminentReason = null;

			for (FeatureSet featureSet : deviceRequiredFeatureSets) {
				Set<VulkanFeature> missingFeatures = featureSet.unsupportedFeatures(vkPhysicalDevice);
				if (!missingFeatures.isEmpty()) {
					LOGGER.warn("Device [{}] does not support required features from FeatureSet [{}], missing: {}", deviceName, featureSet.name(), missingFeatures);
					mostProminentReason = BackendCreationException.Reason.VULKAN_MISSING_FEATURE;

					for (VulkanFeature missingFeature : missingFeatures) {
						missingCapabilities.add(missingFeature.name());
					}
				}
			}

			for (FeatureSet featureSet : deviceRequiredFeatureSets) {
				Set<String> missingExtensions = featureSet.unsupportedExtensions(deviceExtensions);
				if (!missingExtensions.isEmpty()) {
					LOGGER.warn("Device [{}] does not support required extensions from FeatureSet [{}], missing: {}", deviceName, featureSet.name(), missingExtensions);
					mostProminentReason = BackendCreationException.Reason.VULKAN_MISSING_EXTENSION;
					missingCapabilities.addAll(missingExtensions);
				}
			}

			if (physicalDevice.graphicsQueueFamilyAndIndex() == null) {
				LOGGER.warn("Device [{}] does not have a graphics queue", deviceName);
				mostProminentReason = BackendCreationException.Reason.VULKAN_NO_GRAPHICS_QUEUE;
				missingCapabilities.add("COMBINED_GRAPHICS_COMPUTE_PRESENT_QUEUE");
			}

			if (physicalDevice.vkPhysicalDeviceProperties().apiVersion() < VK12.VK_API_VERSION_1_2) {
				LOGGER.warn("Device [{}] does not support Vulkan 1.2", deviceName);
				mostProminentReason = BackendCreationException.Reason.VULKAN_DEVICE_VERSION_TOO_LOW;
				missingCapabilities.add("VULKAN_CORE_1_2");
			}

			if (mostProminentReason != null) {
				LOGGER.debug("Device [{}] is not suitable", deviceName);
				return new BackendCreationException("Device missing capabilities", mostProminentReason, missingCapabilities);
			} else {
				assert missingCapabilities.isEmpty();
				LOGGER.debug("Device [{}] is suitable", deviceName);
				return null;
			}
		}
	}

	private static VkDevice createDevice(final FeatureSet featureSet, final VulkanPhysicalDevice physicalDevice) throws BackendCreationException {
		try (MemoryStack stack = MemoryStack.stackPush()) {
			VkPhysicalDeviceFeatures2 deviceFeatures = VkPhysicalDeviceFeatures2.calloc(stack).sType$Default();

			for (VulkanFeature requiredDeviceFeature : featureSet.features()) {
				requiredDeviceFeature.set(deviceFeatures, true, stack);
			}

			Int2IntMap queuesToCreate = physicalDevice.queueFamilyCreateInfoMap();
			Buffer queueCreationInfo = VkDeviceQueueCreateInfo.calloc(queuesToCreate.size(), stack);

			for (Entry familyCount : queuesToCreate.int2IntEntrySet()) {
				queueCreationInfo.sType$Default();
				queueCreationInfo.queueFamilyIndex(familyCount.getIntKey());
				queueCreationInfo.pQueuePriorities(stack.callocFloat(familyCount.getIntValue()));
				queueCreationInfo.position(queueCreationInfo.position() + 1);
			}

			queueCreationInfo.position(0);
			PointerBuffer enabledExtensionsBuffer = stack.callocPointer(featureSet.extensions().size());

			for (String name : featureSet.extensions()) {
				enabledExtensionsBuffer.put(stack.UTF8(name));
			}

			enabledExtensionsBuffer.flip();
			VkDeviceCreateInfo deviceCreateInfo = VkDeviceCreateInfo.calloc(stack).sType$Default();
			deviceCreateInfo.pNext(deviceFeatures.pNext());
			deviceCreateInfo.pQueueCreateInfos(queueCreationInfo);
			deviceCreateInfo.ppEnabledExtensionNames(enabledExtensionsBuffer);
			deviceCreateInfo.pEnabledFeatures(deviceFeatures.features());
			PointerBuffer pointer = stack.callocPointer(1);
			VulkanUtils.throwIfFailure(
				VK12.vkCreateDevice(physicalDevice.vkPhysicalDevice(), deviceCreateInfo, null, pointer),
				"Failed to create device",
				BackendCreationException.Reason.VULKAN_NO_DEVICE
			);
			return new VkDevice(pointer.get(0), physicalDevice.vkPhysicalDevice(), deviceCreateInfo);
		}
	}
}
